import java.io.FileOutputStream;
import java.io.IOException;
public class FileOutputStreamExample {
    public static void main(String[] args) {
        String filePath = "outputfile.bin";
        String data = "Hello, World!";
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            fos.write(data.getBytes()); // Convert the string to bytes and write
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
