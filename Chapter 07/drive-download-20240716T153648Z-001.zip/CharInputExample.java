import java.io.IOException;
import java.io.InputStreamReader;
public class CharInputExample {
    public static void main(String[] args) {
        InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        System.out.println("Enter some text:");
        try {
            int charData;
            while ((charData = inputStreamReader.read()) != -1) {
                System.out.print((char) charData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
