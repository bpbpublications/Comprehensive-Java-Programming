import java.io.FileInputStream;
import java.io.IOException;
public class FileInputStreamExample {
    public static void main(String[] args) {
        String filePath = "inputfile.bin";
        try (FileInputStream fis = new FileInputStream(filePath)) {
            int byteData;
            while ((byteData = fis.read()) != -1) {
                System.out.print((char) byteData); // Print the byte data as characters
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
