import java.io.IOException;
import java.io.InputStream;
public class ByteInputExample {
    public static void main(String[] args) {
        InputStream inputStream = System.in;
        System.out.println("Enter some text:");
        try {
            int byteData;
            while ((byteData = inputStream.read()) != -1) {
                System.out.print((char) byteData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
