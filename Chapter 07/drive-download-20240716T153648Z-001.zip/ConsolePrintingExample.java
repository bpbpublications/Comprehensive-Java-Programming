public class ConsolePrintingExample {
    public static void main(String[] args) {
        // Using print() to print without a newline
        System.out.print("Hello, ");
        System.out.print("world!");
        
        // Move to the next line using println()
        System.out.println();
        
        // Using println() to print with a newline
        System.out.println("This is a new line.");
        
        // Using printf() for formatted printing
        String name = "Alice";
        int age = 30;
        double height = 5.7;
        //using println to print string and variable
        System.out.println("Name: " + name);

         
        System.out.printf("Name: %s, Age: %d, Height: %.1f feet%n", name, age, height);
        
        // Using println() to print multiple lines
        System.out.println("Here are some numbers:");
        System.out.println(1);
        System.out.println(2);
        System.out.println(3);
        
        // Using print() to print numbers on the same line
        System.out.print(4);
        System.out.print(", ");
        System.out.print(5);
        System.out.print(", ");
        System.out.print(6);
        System.out.println();
        
        // Using printf() for alignment
        System.out.printf("%-10s %-10s %-10s%n", "Name", "Age", "Height");
        System.out.printf("%-10s %-10d %-10.1f%n", "Bob", 25, 5.9);
        System.out.printf("%-10s %-10d %-10.1f%n", "Carol", 32, 5.4);
    }
}
