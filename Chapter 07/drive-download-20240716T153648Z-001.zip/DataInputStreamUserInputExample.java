import java.io.DataInputStream;
import java.io.IOException;
public class DataInputStreamUserInputExample {
    public static void main(String[] args) {
        DataInputStream dis = new DataInputStream(System.in);
        try {
            System.out.print("Enter an integer: ");
            int intValue = dis.readInt();
            System.out.println("You entered: " + intValue);
            System.out.print("Enter a double: ");
            double doubleValue = dis.readDouble();
            System.out.println("You entered: " + doubleValue);
            System.out.print("Enter a boolean: ");
            boolean booleanValue = dis.readBoolean();
            System.out.println("You entered: " + booleanValue);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
