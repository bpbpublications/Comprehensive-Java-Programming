import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class BufferedWriterExample {
    public static void main(String[] args) {
        String filePath = "output.txt";
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filePath))) {
            bufferedWriter.write("Hello, World!");
            bufferedWriter.newLine(); // Add a new line
            bufferedWriter.write("Welcome to file handling in Java.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
