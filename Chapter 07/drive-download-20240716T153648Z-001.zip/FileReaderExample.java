import java.io.FileReader;
import java.io.IOException;
public class FileReaderExample {
    public static void main(String[] args) {
        String filePath = "example.txt";
        try (FileReader fileReader = new FileReader(filePath)) {
            int charData;
            while ((charData = fileReader.read()) != -1) {
                System.out.print((char) charData); // Print the character data
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
