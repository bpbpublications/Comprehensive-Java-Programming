// UserServlet.java
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
	
public class UserServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
	        // Retrieving form data
	        String username = request.getParameter("username");
	        String age = request.getParameter("age");
	
	        // Processing the data (e.g., simple validation)
	        if (username != null && !username.isEmpty() && age != null && !age.isEmpty()) {
	            request.setAttribute("userName", username);
	            request.setAttribute("userAge", age);
	
	            // Forwarding the request to a JSP page
	            RequestDispatcher dispatcher = request.getRequestDispatcher("display.jsp");
	            dispatcher.forward(request, response);
	        } else {
	            // Redirecting to an error page or back to the form
	            response.sendRedirect("error.jsp");
	        }
	    }
	}
