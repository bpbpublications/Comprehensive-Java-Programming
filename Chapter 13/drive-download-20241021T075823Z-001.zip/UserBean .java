package com.example;
	
import java.io.Serializable;
	
	public class 
implements Serializable {
	    private String name;
	    private String email;
	
	    // No-argument constructor
	    public UserBean() {}
	
	    // Getter for name
	    public String getName() {
        return name;
	    }
	
	    // Setter for name
	    public void setName(String name) {
	        this.name = name;
	    }
	
	    // Getter for email
	    public String getEmail() {
        return email;
	    }
	
	    // Setter for email
	    public void setEmail(String email) {
	        this.email = email;
	    }
	}
